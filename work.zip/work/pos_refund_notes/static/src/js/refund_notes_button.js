/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { SelectionPopup } from "@point_of_sale/app/utils/input_popups/selection_popup";
import { InvoiceButton } from "@point_of_sale/app/screens/ticket_screen/invoice_button/invoice_button";
import { PosDB } from "@point_of_sale/app/store/db";
import { Component, useRef } from "@odoo/owl";
import { _t } from "@web/core/l10n/translation";
import { PosCollection, Order, Product } from "@point_of_sale/app/store/models";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { ConnectionLostError, RPCError } from "@web/core/network/rpc_service";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { reactive } from "@odoo/owl";
import { PosBus } from "@point_of_sale/app/bus/pos_bus_service";

InvoiceButton.components = {
    ...InvoiceButton.components,
    SelectionPopup
};

patch(InvoiceButton.prototype, {
    setup(){
        super.setup(...arguments)
        this.popup = useService("popup");
        this.orm = useService("orm");
        this.db = new PosDB();
        this.loadSelectedRefundNote();
    },

    async loadSelectedRefundNote() {
        try {
            this.selectedRefundNote = await this.db.load("SELECTED_REFUND_NOTE");
        } catch (error) {
            console.error("Error loading selected refund note:", error);
        }
    }
});

patch(InvoiceButton.prototype, {
    async refundNote() {
        try {
            const refundNotes = await this.orm.call("pos.refund.notes", "search_read", [[['pos_display', '=', true]]]);

            const { confirmed, payload: selectedNote } = await this.popup.add(SelectionPopup, {
                title: _t("Select Refund Note"),
                list: refundNotes.map(note => ({
                    id: note.id,
                    label: note.refund_note,
                    isSelected: this.selectedRefundNote && this.selectedRefundNote.id === note.id, // Check if note is selected
                    item: note,
                })),
            });

            if (confirmed && selectedNote) {
                await this.saveSelectedRefundNote(selectedNote);
            }
        } catch (error) {
            console.error("Error:", error);
            const popup = useService("popup");
            popup.add(ErrorPopup, {
                title: _t("Error"),
                body: _t("An error occurred while processing the refund note."),
            });
        }
    },

    async saveSelectedRefundNote(selectedNote) {
        this.selectedRefundNote = selectedNote; // Update selected refund note
        await this.db.save("SELECTED_REFUND_NOTE", selectedNote);
    }
});
patch(Order.prototype, {
         setup(){
            super.setup(...arguments)
            this.db = new PosDB();

        },
})
patch(Order.prototype, {
    async pay() {
        if (!this.canPay()) {
            return;
        }

        const allLinesPositive = this.orderlines.every(line => line.get_quantity() > 0);

        if (allLinesPositive) {
            await this.db.save("SELECTED_REFUND_NOTE", null);
        }

        if (
            this.orderlines.some(
                line => line.get_product().tracking !== "none" && !line.has_valid_product_lot()
            ) &&
            (this.pos.picking_type.use_create_lots || this.pos.picking_type.use_existing_lots)
        ) {
            const { confirmed } = await this.env.services.popup.add(ConfirmPopup, {
                title: _t("Some Serial/Lot Numbers are missing"),
                body: _t(
                    "You are trying to sell products with serial/lot numbers, but some of them are not set.\nWould you like to proceed anyway?"
                ),
                confirmText: _t("Yes"),
                cancelText: _t("No"),
            });
            if (confirmed) {
                this.pos.mobile_pane = "right";
                this.env.services.pos.showScreen("PaymentScreen");
            }
        } else {
            this.pos.mobile_pane = "right";
            this.env.services.pos.showScreen("PaymentScreen");
        }
    }
});
patch(PaymentScreen.prototype, {
    setup(){
        super.setup(...arguments)
        this.db = new PosDB();
    },
});

patch(PaymentScreen.prototype, {
    async _finalizeValidation() {
        if (this.currentOrder.is_paid_with_cash() || this.currentOrder.get_change()) {
            this.hardwareProxy.openCashbox();
        }

        this.currentOrder.date_order = luxon.DateTime.now();
        for (const line of this.paymentLines) {
            if (!line.amount === 0) {
                this.currentOrder.remove_paymentline(line);
            }
        }
        this.currentOrder.finalized = true;

        this.env.services.ui.block();
        let syncOrderResult;
        try {
            // 1. Save order to server.
            this.selectedRefundNote = this.db.load("SELECTED_REFUND_NOTE");
            const refundNoteId = this.selectedRefundNote ? this.selectedRefundNote['id'] : null;
            syncOrderResult = await this.pos.push_single_order(this.currentOrder);

            if (!syncOrderResult) {
                return;
            }

            // 2. Invoice.
            if (this.shouldDownloadInvoice() && this.currentOrder.is_to_invoice()) {
                if (syncOrderResult[0]?.account_move) {
                    await this.report.doAction("account.account_invoices", [syncOrderResult[0].account_move]);
                    const soto = await this.orm.call("ir.config_parameter", "get_param", ["pos_refund_notes.enable_js_file"]);
                    this.soto = soto;
                    console.log(this.soto)
                    if (this.soto) {
                        await this.orm.call("account.move", "update_refund_notes", [
                            syncOrderResult[0].account_move, refundNoteId
                        ]);
                        console.log(refundNoteId)
                    } else {
                        console.log("Else - Going to Set Database value as Null")
                        await this.db.save("SELECTED_REFUND_NOTE", null);
                    }

                } else {
                    throw {
                        code: 401,
                        message: "Backend Invoice",
                        data: { order: this.currentOrder },
                    };
                }
            }
        } catch (error) {
            if (error instanceof ConnectionLostError) {
                this.pos.showScreen(this.nextScreen);
                Promise.reject(error);
                return error;
            } else {
                throw error;
            }
        } finally {
            this.env.services.ui.unblock()
        }

        // 3. Post process.
        if (
            syncOrderResult &&
            syncOrderResult.length > 0 &&
            this.currentOrder.wait_for_push_order()
        ) {
            await this.postPushOrderResolve(syncOrderResult.map((res) => res.id));
        }

        await this.afterOrderValidation(!!syncOrderResult && syncOrderResult.length > 0);
    }
});
