{
    'name': 'Refund Notes in PoS',
    'category': 'General',
    'summary': 'Refund notes Feature for Point of Sale Module!',
    'author': 'Silent Infotech ',
    'description': """ This module enables users to issue refund notes directly from the Point of Sale interface and manage them conveniently through the Invoicing module. Enhance your PoS system with streamlined refund management for improved customer satisfaction.""",
    'depends':['point_of_sale','web','account'],
    'version': '17.0.1.0.0',
    'website': 'https://silentinfotech.com',
    'author': 'Silent Infotech Pvt. Ltd.',
    'price': 0.00,
    'currency': 'USD',
    'license': u'OPL-1',
    'application': True,
    'auto_install': False,
    'installable': True,
    'data': [
        'security/ir.model.access.csv',
        'views/refund_notes_view.xml'],
    'assets':{
        'point_of_sale._assets_pos':[
            'pos_refund_notes/static/src/**/*',
        ]
    }
}
