from odoo import models, fields, api

class PosRefundNote(models.Model):
    _name = 'pos.refund.notes'
    _description = 'Pos Refund Notes'
    _rec_name = 'refund_note'

    refund_note = fields.Char(string='Notes')
    pos_display = fields.Boolean(string='Display in PoS')

    @api.model
    def get_pos_display_refund_notes(self):
        refund_notes = self.search([('pos_display', '=', True)])
        return refund_notes
