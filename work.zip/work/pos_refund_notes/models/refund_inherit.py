from odoo import models, fields, api

class AccountMove(models.Model):
    _inherit = 'account.move'

    refund_note = fields.Many2one('pos.refund.notes', string='Refund Note')

    @api.model
    def update_refund_notes(self, move_id, refund_note_id):
        self.browse(move_id).write({'refund_note': refund_note_id})
        print(move_id, refund_note_id)
        return refund_note_id

