from odoo import models, fields, api

class MyModel(models.TransientModel):
    _inherit = 'res.config.settings'

    enable_js_file = fields.Boolean(string='Enable JS File', config_parameter='pos_refund_notes.enable_js_file', default=True)
