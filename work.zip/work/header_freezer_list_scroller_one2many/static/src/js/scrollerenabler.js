/* @odoo-module */

import { Component } from "@odoo/owl";
import { _t } from "@web/core/l10n/translation";
import { useService } from "@web/core/utils/hooks";
import { patch } from "@web/core/utils/patch";
import { FormController } from "@web/views/form/form_controller";

patch(FormController.prototype, {
    async setup() {
        await super.setup();
        const soto = await this.orm.call("ir.config_parameter", "get_param", [
            "header_freezer_list_scroller_one2many.enable_js_file",
        ]);

        this.toggleCss(soto);
    },

    toggleCss(enable) {
        this.enableCss = enable;
        localStorage.setItem('enableCss', this.enableCss.toString());
        this.updateCss();
        const notification = this.env.services.notification;

    },

    updateCss() {
        const styleId = 'customFieldStyles';
        let styleElement = document.getElementById(styleId);
        if (!styleElement) {
            styleElement = document.createElement('style');
            styleElement.id = styleId;
            document.head.appendChild(styleElement);
        }

        const css = `
            /* Extra small devices (phones, less than 576px) */
            @media (max-width: 575.98px) {
                .o_list_renderer.o_renderer.table-responsive {
                    max-height: ${this.enableCss ? '20vh' : 'unset'};
                    overflow-y: ${this.enableCss ? 'auto' : 'unset'};
                }
            }

            /* Small devices (landscape phones, 576px and up) */
            @media (min-width: 576px) {
                .o_list_renderer.o_renderer.table-responsive {
                    max-height: ${this.enableCss ? '30vh' : 'unset'};
                    overflow-y: ${this.enableCss ? 'auto' : 'unset'};
                }
            }

            /* Medium devices (tablets, 768px and up) */
            @media (min-width: 768px) {
                .o_list_renderer.o_renderer.table-responsive {
                    max-height: ${this.enableCss ? '40vh' : 'unset'};
                    overflow-y: ${this.enableCss ? 'auto' : 'unset'};
                }
            }

            /* Large devices (desktops, 992px and up) */
            @media (min-width: 992px) {
                .o_list_renderer.o_renderer.table-responsive {
                    max-height: ${this.enableCss ? '50vh' : 'unset'};
                    overflow-y: ${this.enableCss ? 'auto' : 'unset'};
                }
            }

            /* Extra large devices (large desktops, 1200px and up) */
            @media (min-width: 1200px) {
                .o_list_renderer.o_renderer.table-responsive {
                    max-height: ${this.enableCss ? '60vh' : 'unset'};
                    overflow-y: ${this.enableCss ? 'auto' : 'unset'};
                }
            }
        `;

        styleElement.innerHTML = this.enableCss ? css : '';
    }
});
