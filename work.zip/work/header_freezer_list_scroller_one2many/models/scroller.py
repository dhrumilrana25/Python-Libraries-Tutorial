from odoo import models, fields, api

class MyModel(models.TransientModel):
    _inherit = 'res.config.settings'

    enable_js_file = fields.Boolean(string='Enable JS File', config_parameter='header_freezer_list_scroller_one2many.enable_js_file')

