# -*- coding: utf-8 -*-
{
    'name': 'List Scroller & Header Freezer',
    'category': 'General',
    'summary': 'Custom Feature for implementing the scroller feature in One2Many List View and for freezing headers!',
    'author': 'Silent Infotech Pvt. Ltd.',
    'description': """For making the One2Many fields more readable and Efficient!""",
    'website':'https://silentinfotech.com',
    'depends': ['base', 'web'],
    'license': u'OPL-1',
    'version': '17.0.1.0.0',
    'price': 0.00,
    'currency': 'USD',
    'sequence':'4',
    'application': True,
    'auto_install': False,
    'installable': True,
    'data': [
             'views/scroller_view.xml'],
    'assets': {
        'web.assets_backend': [
            'header_freezer_list_scroller_one2many/static/src/**/*',
            'header_freezer_list_scroller_one2many/static/src/css/*',
        ]
    },
}
